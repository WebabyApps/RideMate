import { Timestamp } from 'firebase/firestore';
import { z } from 'zod';

export type UserProfile = {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  avatarUrl: string;
  rating: number;
};

export type Passenger = {
  id: string;
  firstName: string;
  lastName: string;
  avatarUrl: string;
}

export type Ride = {
  id: string;
  offererId: string;
  offererName: string;
  offererAvatarUrl: string;
  offererRating: number;
  origin: string;
  destination: string;
  departureTime: Timestamp;
  availableSeats: number;
  totalSeats: number;
  cost: number;
  petsAllowed: boolean;
  largeBagsAllowed: boolean;
  createdAt: Timestamp;
  bookingId?: string; // Optional: only present for the user who booked it
};

export type Booking = {
    id: string;
    rideId: string;
    userId: string;
    passengerName: string;
    passengerAvatarUrl: string;
    createdAt: Timestamp;
};

export type Message = {
  id: string;
  rideId: string;
  senderId: string;
  receiverId: string;
  text: string;
  createdAt: Timestamp;
};

// Genkit Flow Schemas
export const BookRideInputSchema = z.object({
  rideId: z.string(),
});
export type BookRideInput = z.infer<typeof BookRideInputSchema>;

export const BookRideOutputSchema = z.object({
  success: z.boolean(),
  message: z.string(),
  bookingId: z.string().optional(),
});
export type BookRideOutput = z.infer<typeof BookRideOutputSchema>;


export const OptimizeCarpoolRouteInputSchema = z.object({
  waypoints: z.array(z.string()).min(2, "At least two waypoints are required."),
  notes: z.string().optional(),
});
export type OptimizeCarpoolRouteInput = z.infer<typeof OptimizeCarpoolRouteInputSchema>;

export const OptimizeCarpoolRouteOutputSchema = z.object({
  order: z.array(z.string()),
  notes: z.string(),
});
export type OptimizeCarpoolRouteOutput = z.infer<typeof OptimizeCarpoolRouteOutputSchema>;
