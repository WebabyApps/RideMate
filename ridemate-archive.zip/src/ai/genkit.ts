import { genkit } from 'genkit';
import { googleAI } from '@genkit-ai/google-genai';
import { defineDotprompt } from 'genkit/dotprompt';

export const ai = genkit({
  plugins: [
    googleAI(),
  ],
  logLevel: 'debug',
  enableTracingAndMetrics: true,
});
