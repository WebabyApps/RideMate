const fs = require('fs');
const archiver = require('archiver');

const archiveName = 'ridemate-archive.zip';
const output = fs.createWriteStream(archiveName);
const archive = archiver('zip', {
  zlib: { level: 9 } // Sets the compression level.
});

// listen for all archive data to be written
// 'close' event is fired only when a file descriptor is involved
output.on('close', function() {
  console.log(`\n✅ Success! Project archived as ${archiveName}`);
  console.log(`Total size: ${(archive.pointer() / 1024 / 1024).toFixed(2)} MB`);
});

// This event is fired when the data source is drained no matter what was sent.
// It is completely separate from whether the destination is writable or not.
archive.on('end', function() {
  console.log('Data has been drained');
});

// good practice to catch warnings (ie stat failures and other non-blocking errors)
archive.on('warning', function(err) {
  if (err.code === 'ENOENT') {
    // log warning
    console.warn('Warning:', err);
  } else {
    // throw error
    throw err;
  }
});

// good practice to catch this error explicitly
archive.on('error', function(err) {
  throw err;
});

// pipe archive data to the file
archive.pipe(output);

console.log('Creating zip archive...');

// append all files and directories, ignoring specified patterns
archive.glob('**/*', {
  cwd: __dirname + '/../', // run from project root
  ignore: [
    'node_modules/**',
    '.next/**',
    '.git/**',
    archiveName // ignore the output file itself
  ]
});

// finalize the archive (ie we are done appending files but streams have to finish yet)
// 'close', 'end' or 'finish' may be fired right after calling this method so register to them beforehand
archive.finalize();
