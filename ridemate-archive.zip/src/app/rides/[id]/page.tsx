
'use client';

import { useRouter, useParams } from "next/navigation";
import { useMemo, useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { StarRating } from "@/components/star-rating";
import { Calendar, Clock, Users, DollarSign, MessageSquare, AlertCircle, Dog, Briefcase } from "lucide-react";
import { format } from 'date-fns';
import { useUser, useFirestore, useDoc, useMemoFirebase } from "@/firebase";
import { collection, doc, serverTimestamp, increment, getDocs, Timestamp, where, query, getDoc, writeBatch, deleteDoc } from "firebase/firestore";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "@/hooks/use-toast";
import { RideMap } from "@/components/ride-map";
import Link from 'next/link';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import type { Ride, Booking, UserProfile } from "@/lib/types";
import { PassengerList } from "./passenger-list";
import { bookRide } from "@/ai/flows/book-ride";

export default function RidePage() {
  const params = useParams();
  const rideId = typeof params.id === 'string' ? params.id : '';
  const { user, isUserLoading } = useUser();
  const firestore = useFirestore();
  const router = useRouter();
  const [isBooked, setIsBooked] = useState(false);
  const [bookingId, setBookingId] = useState<string | null>(null);
  const [isMyBookingLoading, setIsMyBookingLoading] = useState(true);
  const [isActionPending, setIsActionPending] = useState(false);


  const rideDocRef = useMemoFirebase(() => {
    if (!firestore || !rideId) return null;
    return doc(firestore, 'rides', rideId);
  }, [firestore, rideId]);

  const { data: ride, isLoading: isRideLoading, error: rideError } = useDoc<Ride>(rideDocRef);

  const isDriver = useMemo(() => user?.uid === ride?.offererId, [user, ride]);

  useEffect(() => {
    const checkBookingStatus = async () => {
      if (!firestore || !user || !rideId || isDriver) {
        setIsMyBookingLoading(false);
        return;
      }
      setIsMyBookingLoading(true);
      try {
        const bookingsColRef = collection(firestore, 'rides', rideId, 'bookings');
        const q = query(bookingsColRef, where("userId", "==", user.uid));
        const bookingsSnap = await getDocs(q);
        
        if (!bookingsSnap.empty) {
          const userBooking = bookingsSnap.docs[0];
          setIsBooked(true);
          setBookingId(userBooking.id);
        } else {
          setIsBooked(false);
          setBookingId(null);
        }
      } catch (error) {
        console.error("Error checking booking status:", error);
        setIsBooked(false);
        setBookingId(null);
      } finally {
        setIsMyBookingLoading(false);
      }
    };

    if (!isUserLoading && !isRideLoading) {
      checkBookingStatus();
    }
  }, [firestore, user, rideId, isDriver, isUserLoading, isRideLoading]);
  
  const availableSeats = ride ? ride.availableSeats : 0;
  const isRideFull = availableSeats <= 0;

  const handleBookSeat = async () => {
    if (!user || user.isAnonymous) {
      toast({ title: "Please Sign In", description: "You must have an account to book a ride.", variant: "destructive" });
      router.push('/signup');
      return;
    }
    if (!rideId) return;

    setIsActionPending(true);

    try {
      const result = await bookRide({ rideId });

      if (result.success) {
        setIsBooked(true);
        setBookingId(result.bookingId);
        toast({ title: "Seat Booked!", description: "You have successfully booked a seat." });
        // Manually trigger a re-render or data re-fetch if needed
      } else {
        throw new Error(result.message);
      }
    } catch (error: any) {
      console.error("Error booking seat:", error);
      toast({ title: "Booking Failed", description: error.message || "Could not book a seat. Please try again.", variant: "destructive" });
    } finally {
      setIsActionPending(false);
    }
  };
  
  const handleCancelBooking = async () => {
    if (!firestore || !user || !rideId || !bookingId || !rideDocRef) return;

    setIsActionPending(true);
    try {
      const batch = writeBatch(firestore);

      const bookingDocRef = doc(firestore, 'rides', rideId, 'bookings', bookingId);
      batch.delete(bookingDocRef);
      batch.update(rideDocRef, { availableSeats: increment(1) });

      await batch.commit();
    
      setIsBooked(false);
      setBookingId(null);
      toast({ title: "Booking Cancelled", description: "Your booking has been cancelled." });
    } catch(error: any) {
       console.error("Error cancelling booking:", error);
       toast({ title: "Cancellation Failed", description: error.message || "Could not cancel booking. Please try again.", variant: "destructive" });
    } finally {
      setIsActionPending(false);
    }
  };
  
  const isLoading = isUserLoading || isRideLoading || isMyBookingLoading;

  if (isLoading) {
    return (
        <div className="container mx-auto max-w-5xl px-4 md:px-6 py-8">
            <div className="grid md:grid-cols-3 gap-8 items-start">
                <div className="md:col-span-2 space-y-8">
                    <Skeleton className="h-96 w-full" />
                    <Skeleton className="h-48 w-full" />
                </div>
                <div className="space-y-6 md:sticky top-24">
                    <Skeleton className="h-64 w-full" />
                    <Skeleton className="h-48 w-full" />
                    <Skeleton className="h-12 w-full" />
                </div>
            </div>
        </div>
    );
  }
  
  if (!ride) {
     return (
        <div className="container mx-auto max-w-2xl px-4 md:px-6 py-12 text-center">
            <Card className="p-8">
                <AlertCircle className="mx-auto h-12 w-12 text-destructive" />
                <h1 className="mt-4 text-3xl font-bold tracking-tight text-foreground sm:text-5xl">Ride Not Found</h1>
                <p className="mt-6 text-base leading-7 text-muted-foreground">Sorry, we couldn’t find the ride you’re looking for.</p>
                <div className="mt-10 flex items-center justify-center gap-x-6">
                    <Button asChild>
                      <Link href="/rides">Go back to rides</Link>
                    </Button>
                </div>
            </Card>
        </div>
    )
  }

  const departureDate = ride.departureTime?.toDate ? ride.departureTime.toDate() : new Date();

  return (
    <div className="container mx-auto max-w-5xl px-4 md:px-6 py-8">
      {rideError && (
        <Card className="mb-4 bg-destructive/10 border-destructive/50 text-destructive-foreground">
          <CardContent className="p-4">
            <p className="text-sm">Some ride data could not be loaded. You may not have permission to view this ride.</p>
          </CardContent>
        </Card>
      )}

      <div className="grid md:grid-cols-3 gap-8 items-start">
        <div className="md:col-span-2 space-y-8">
          <Card>
            <CardHeader>
              <CardTitle className="font-headline text-3xl">{ride.origin} to {ride.destination}</CardTitle>
              <CardDescription className="flex items-center gap-4 pt-2">
                 <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    <span>{format(departureDate, 'EEEE, MMMM d, yyyy')}</span>
                </div>
                <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    <span>at {format(departureDate, 'p')}</span>
                </div>
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-0">
               <div className="relative w-full h-64 md:h-96 rounded-lg overflow-hidden border">
                  <RideMap origin={ride.origin} destination={ride.destination} />
                </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="font-headline">Ride Details</CardTitle>
            </CardHeader>
            <CardContent className="pt-0 grid grid-cols-2 md:grid-cols-4 gap-6">
                <div className="flex flex-col items-center text-center">
                    <Users className="w-8 h-8 text-primary mb-2" />
                    <p className="font-semibold">{ride.availableSeats} of {ride.totalSeats} Seats Left</p>
                </div>
                 <div className="flex flex-col items-center text-center">
                    <DollarSign className="w-8 h-8 text-accent mb-2" />
                    <p className="font-semibold text-2xl">${ride.cost?.toFixed(2) || '?.??'}</p>
                    <p className="text-sm text-muted-foreground">per seat</p>
                </div>
                {ride.petsAllowed && (
                    <div className="flex flex-col items-center text-center">
                        <Dog className="w-8 h-8 text-primary mb-2" />
                        <p className="font-semibold">Pets Allowed</p>
                    </div>
                )}
                {ride.largeBagsAllowed && (
                    <div className="flex flex-col items-center text-center">
                        <Briefcase className="w-8 h-8 text-primary mb-2" />
                        <p className="font-semibold">Large Bags</p>
                    </div>
                )}
            </CardContent>
          </Card>
        </div>
        <div className="space-y-6 md:sticky top-24">
            <Card className="text-center">
                <CardHeader>
                    <CardTitle className="font-headline">Driver</CardTitle>
                </CardHeader>
                <CardContent className="flex flex-col items-center gap-4">
                    <Avatar className="w-24 h-24 border-4 border-primary">
                      <AvatarImage src={ride.offererAvatarUrl} alt={ride.offererName} />
                      <AvatarFallback>{ride.offererName?.charAt(0) || 'D'}</AvatarFallback>
                    </Avatar>
                    <div className="text-center">
                      <p className="font-bold text-xl">{ride.offererName}</p>
                      <StarRating rating={ride.offererRating || 0} className="justify-center mt-1" />
                    </div>
                    <Button variant="outline" className="w-full">
                      <MessageSquare className="w-4 h-4 mr-2" /> Message {ride.offererName?.split(' ')[0] || 'Driver'}
                    </Button>
                </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="font-headline flex items-center gap-2"><Users className="h-5 w-5"/>Passengers</CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                  {isDriver ? (
                    <PassengerList rideId={rideId} />
                  ) : (
                    <p className="text-sm text-muted-foreground">Passenger list is private.</p>
                  )}
              </CardContent>
            </Card>

            <div className="sticky bottom-4">
                {!isDriver && user && (
                  <>
                    {isBooked ? (
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="outline" size="lg" className="w-full text-lg font-bold" disabled={isActionPending}>
                           {isActionPending ? 'Cancelling...' : 'Cancel Booking'}
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This will remove you from the ride and notify the driver. This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Keep Booking</AlertDialogCancel>
                            <AlertDialogAction onClick={handleCancelBooking}>
                              Yes, Cancel
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    ) : (
                      <Button 
                        size="lg" 
                        className="w-full text-lg font-bold bg-accent hover:bg-accent/90 text-accent-foreground" 
                        onClick={handleBookSeat} 
                        disabled={isRideFull || isActionPending}
                      >
                        {isActionPending ? 'Booking...' : isRideFull ? 'Ride Full' : 'Book a Seat'}
                      </Button>
                    )}
                  </>
                )}
                 {!user && !isUserLoading && (
                    <Button size="lg" className="w-full font-bold" asChild>
                      <Link href="/login">Log in to book</Link>
                    </Button>
                )}
            </div>
        </div>
      </div>
    </div>
  );
}
