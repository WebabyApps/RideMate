
import { NextResponse } from 'next/server';
import { optimizeCarpoolRoute, OptimizeCarpoolRouteInput } from '@/ai/flows/optimize-carpool-route';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const revalidate = 0;

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as OptimizeCarpoolRouteInput;
    
    // Basic validation
    if (!body.waypoints || !Array.isArray(body.waypoints) || body.waypoints.length < 2) {
      return NextResponse.json(
        { ok: false, message: 'At least two waypoints are required.' },
        { status: 400 }
      );
    }

    const result = await optimizeCarpoolRoute({
      waypoints: body.waypoints,
      notes: body.notes,
    });
    
    return NextResponse.json({ ok: true, data: result });
  } catch (error: any) {
    console.error('Error in optimize-route API:', error);
    return NextResponse.json(
      { ok: false, message: error.message || 'An internal server error occurred.' },
      { status: 500 }
    );
  }
}
