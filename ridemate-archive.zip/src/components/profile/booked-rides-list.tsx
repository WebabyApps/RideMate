'use client';

import { useState, useEffect, useCallback } from 'react';
import { collection, query, where, getDocs, doc, writeBatch, documentId, collectionGroup, getDoc } from 'firebase/firestore';
import { useFirestore, useUser } from '@/firebase';
import { useToast } from '@/hooks/use-toast';
import type { Ride, Booking } from '@/lib/types';
import { format } from 'date-fns';
import Link from 'next/link';

import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

export function BookedRidesList() {
    const { user } = useUser();
    const firestore = useFirestore();
    const { toast } = useToast();
    const [bookedRides, setBookedRides] = useState<Ride[] | null>(null);
    const [isLoading, setIsLoading] = useState(true);

    const fetchBookedRides = useCallback(async () => {
        if (!firestore || !user) return;
        setIsLoading(true);
        try {
            const userBookingsQuery = query(collectionGroup(firestore, 'bookings'), where('userId', '==', user.uid));
            const userBookingsSnapshot = await getDocs(userBookingsQuery);
            
            if (userBookingsSnapshot.empty) {
                setBookedRides([]);
                setIsLoading(false);
                return;
            }

            const ridePromises = userBookingsSnapshot.docs.map(async (bookingDoc) => {
                const booking = { id: bookingDoc.id, ...bookingDoc.data() } as Booking;
                const rideDocRef = doc(firestore, 'rides', booking.rideId);
                const rideDocSnap = await getDoc(rideDocRef);

                if (rideDocSnap.exists()) {
                    const rideData = { id: rideDocSnap.id, ...rideDocSnap.data() } as Ride;
                    rideData.bookingId = booking.id; // Attach the bookingId to the ride object.
                    return rideData;
                }
                return null; // Return null if ride doc doesn't exist
            });

            const ridesData = (await Promise.all(ridePromises)).filter((ride): ride is Ride => ride !== null);
            
            ridesData.sort((a, b) => {
              const timeA = a.departureTime?.toDate?.().getTime() || 0;
              const timeB = b.departureTime?.toDate?.().getTime() || 0;
              return timeB - timeA; // Most recent first.
            });

            setBookedRides(ridesData);

        } catch (error) {
            console.error("Error fetching booked rides:", error);
            toast({
                variant: "destructive",
                title: "Error",
                description: "Could not fetch your booked rides.",
            });
            setBookedRides([]);
        } finally {
            setIsLoading(false);
        }
    }, [firestore, user, toast]);

    useEffect(() => {
        if (user) {
            fetchBookedRides();
        } else {
            setIsLoading(false);
            setBookedRides([]);
        }
    }, [user, fetchBookedRides]);


    const handleCancelBooking = async (ride: Ride) => {
        if (!firestore || !user || !ride.bookingId) return;
        
        const batch = writeBatch(firestore);

        const bookingDocRef = doc(firestore, 'rides', ride.id, 'bookings', ride.bookingId);
        const rideDocRef = doc(firestore, 'rides', ride.id);

        batch.delete(bookingDocRef);
        batch.update(rideDocRef, { availableSeats: ride.availableSeats + 1 });

        try {
            await batch.commit();
            
            setBookedRides(prev => prev?.filter(br => br.id !== ride.id) || null);
            
            toast({
                title: "Booking Cancelled",
                description: "You have successfully cancelled your booking.",
            });
        } catch (error) {
             toast({
                variant: "destructive",
                title: "Error",
                description: "Could not cancel booking.",
            });
        }
    };
    
    if (isLoading) {
        return <Skeleton className="h-40 w-full" />;
    }

    if (!bookedRides || bookedRides.length === 0) {
        return (
            <div className="text-center py-10 border-2 border-dashed rounded-lg">
                <p className="text-muted-foreground">You haven't booked any rides.</p>
                <Button asChild variant="link" className="mt-2 text-primary">
                    <Link href="/rides">Find a ride now</Link>
                </Button>
            </div>
        );
    }
  
    return (
        <div className="space-y-4">
        {bookedRides.map((ride) => (
            <Card key={ride.id} className="p-4 flex justify-between items-center">
                <div>
                    <Link href={`/rides/${ride.id}`} className="font-bold hover:underline">{ride.origin} to {ride.destination}</Link>
                    <p className="text-sm text-muted-foreground">{ride.departureTime ? format(ride.departureTime.toDate(), 'PPpp') : 'Date not available'}</p>
                    <p className="text-sm">${ride.cost ? ride.cost.toFixed(2) : '??.??'} per seat</p>
                </div>
                <AlertDialog>
                    <AlertDialogTrigger asChild>
                    <Button variant="outline">Cancel Booking</Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                    <AlertDialogHeader>
                        <AlertDialogTitle>Cancel your booking?</AlertDialogTitle>
                        <AlertDialogDescription>
                        This will remove you from the ride and free up your seat. Are you sure?
                        </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                        <AlertDialogCancel>Keep Booking</AlertDialogCancel>
                        <AlertDialogAction onClick={() => handleCancelBooking(ride)}>
                        Yes, Cancel
                        </AlertDialogAction>
                    </AlertDialogFooter>
                    </AlertDialogContent>
                </AlertDialog>
            </Card>
        ))}
        </div>
    );
}
    