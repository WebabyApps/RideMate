
'use client';

import { useMemo } from 'react';
import { useCollection, useMemoFirebase } from "@/firebase";
import { collection, query } from "firebase/firestore";
import { useFirestore } from "@/firebase";
import { Skeleton } from '@/components/ui/skeleton';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import type { Booking } from "@/lib/types";

function PassengerAvatar({ passenger }: { passenger: Booking }) {
    const displayName = passenger.passengerName || 'Passenger';
    const fallback = displayName.charAt(0) || 'P';

    return (
        <div className="flex items-center gap-2 text-sm" title={displayName}>
            <Avatar className="h-8 w-8">
                <AvatarImage src={passenger.passengerAvatarUrl} alt={displayName} />
                <AvatarFallback>{fallback}</AvatarFallback>
            </Avatar>
            <span className="font-medium">{displayName}</span>
        </div>
    );
}

export function PassengerList({ rideId }: { rideId: string }) {
    const firestore = useFirestore();
    const bookingsQuery = useMemoFirebase(() => {
        if (!firestore || !rideId) return null;
        return query(collection(firestore, 'rides', rideId, 'bookings'));
    }, [firestore, rideId]);

    const { data: passengers, isLoading, error } = useCollection<Booking>(bookingsQuery);

    if (isLoading) {
        return (
            <div className="flex flex-wrap gap-4 mt-2">
                <Skeleton className="h-8 w-28 rounded-full" />
                <Skeleton className="h-8 w-24 rounded-full" />
            </div>
        );
    }
    
    if (error) {
        return <p className="text-sm text-muted-foreground mt-2">Could not load passenger list.</p>;
    }

    if (!passengers || passengers.length === 0) {
        return <p className="text-sm text-muted-foreground mt-2">No passengers have booked yet.</p>;
    }

    return (
      <div className="flex flex-wrap gap-4 mt-2">
        {passengers.map(passenger => (
            <PassengerAvatar key={passenger.id} passenger={passenger} />
        ))}
      </div>
    );
}

    