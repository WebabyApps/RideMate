
import * as admin from 'firebase-admin';

// Initialize Firebase Admin SDK
if (!admin.apps.length) {
    try {
        // First, try to use the service account from environment variables (for local development)
        const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_KEY!);
        admin.initializeApp({
            credential: admin.credential.cert(serviceAccount)
        });
        console.log("Firebase Admin SDK initialized with Service Account.");
    } catch (e) {
        // If that fails, fall back to Application Default Credentials (for deployed environments)
        console.log("Service account not found or invalid, falling back to Application Default Credentials.");
        admin.initializeApp();
    }
}

export const getDb = () => admin.firestore();
export const getAuthAdmin = () => admin.auth();
