export const firebaseConfig = {
  "projectId": "studio-1835169929-c35ab",
  "appId": "1:648798500393:web:88d20a7c714aaf185d8e38",
  "apiKey": "AIzaSyCQ_p4o-gwx__Eicy12UZIGouYfy74ba5k",
  "authDomain": "studio-1835169929-c35ab.firebaseapp.com",
  "measurementId": "G-2Q0ZLY539D",
  "messagingSenderId": "648798500393"
};
