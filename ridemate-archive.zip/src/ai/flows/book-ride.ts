
'use server';
/**
 * @fileOverview A server-side flow for booking a ride.
 *
 * - bookRide - A function that handles the booking process securely.
 */
import { ai } from '@/ai/genkit';
import { getDb } from '@/lib/admin';
import { FieldValue } from 'firebase-admin/firestore';
import { BookRideInputSchema, BookRideOutputSchema, type BookRideInput, type BookRideOutput } from '@/lib/types';


export async function bookRide(input: BookRideInput): Promise<BookRideOutput> {
  return bookRideFlow(input);
}

const bookRideFlow = ai.defineFlow(
  {
    name: 'bookRideFlow',
    inputSchema: BookRideInputSchema,
    outputSchema: BookRideOutputSchema,
    auth: (auth, input) => {
        if (!auth) {
            throw new Error('You must be logged in to book a ride.');
        }
    },
  },
  async (input, { auth }) => {
    const db = getDb();
    const { rideId } = input;
    const userId = auth!.uid;

    try {
        const rideRef = db.collection('rides').doc(rideId);
        const userRef = db.collection('users').doc(userId);

        return await db.runTransaction(async (transaction) => {
            const rideDoc = await transaction.get(rideRef);
            if (!rideDoc.exists) {
                return { success: false, message: 'Ride not found.' };
            }
            
            const rideData = rideDoc.data();
            if (!rideData || rideData.availableSeats <= 0) {
                 return { success: false, message: 'No available seats on this ride.' };
            }
            
            const userDoc = await transaction.get(userRef);
            if (!userDoc.exists) {
                return { success: false, message: 'User profile not found.' };
            }
            const userData = userDoc.data();
            
            const bookingRef = rideRef.collection('bookings').doc();
            
            transaction.update(rideRef, {
                availableSeats: FieldValue.increment(-1),
            });
            
            transaction.set(bookingRef, {
                rideId: rideId,
                userId: userId,
                passengerName: `${userData?.firstName || ''} ${userData?.lastName || ''}`.trim() || 'Anonymous',
                passengerAvatarUrl: userData?.avatarUrl || `https://picsum.photos/seed/${userId}/200/200`,
                createdAt: FieldValue.serverTimestamp(),
            });

            return { success: true, bookingId: bookingRef.id, message: "Booking successful!" };
        });

    } catch (error: any) {
        console.error('Error in bookRideFlow:', error);
        return { success: false, message: error.message || 'An unexpected server error occurred.' };
    }
  }
);
