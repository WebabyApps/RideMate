
'use server';
/**
 * @fileOverview A carpool route optimization AI agent.
 *
 * - optimizeCarpoolRoute - A function that handles the carpool route optimization process.
 */

import { ai } from '@/ai/genkit';
import { OptimizeCarpoolRouteInputSchema, OptimizeCarpoolRouteOutputSchema, type OptimizeCarpoolRouteInput, type OptimizeCarpoolRouteOutput } from '@/lib/types';


const optimizeCarpoolRoutePrompt = ai.definePrompt(
  {
    name: 'optimizeCarpoolRoutePrompt',
    input: { schema: OptimizeCarpoolRouteInputSchema },
    output: { schema: OptimizeCarpoolRouteOutputSchema },
    prompt: `You are a carpool route optimization expert. Your task is to determine the most efficient order of waypoints for a carpool trip.

Consider the provided waypoints and any optional notes.

Waypoints:
{{#each waypoints}}
- {{{this}}}
{{/each}}

{{#if notes}}
User Notes: {{{notes}}}
{{/if}}

Please provide the optimized route plan in the requested JSON format. The 'order' field should list the waypoints in the suggested travel sequence.`,
  },
);

const optimizeCarpoolRouteFlow = ai.defineFlow(
  {
    name: 'optimizeCarpoolRouteFlow',
    inputSchema: OptimizeCarpoolRouteInputSchema,
    outputSchema: OptimizeCarpoolRouteOutputSchema,
  },
  async (input) => {
    const { output } = await optimizeCarpoolRoutePrompt(input);
    return output!;
  }
);


export async function optimizeCarpoolRoute(input: OptimizeCarpoolRouteInput): Promise<OptimizeCarpoolRouteOutput> {
  return optimizeCarpoolRouteFlow(input);
}
