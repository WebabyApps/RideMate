import { NextResponse } from 'next/server';
import { getDb } from '@/lib/admin';
import type { UserProfile } from '@/lib/types';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const revalidate = 0;

function chunk<T>(arr: T[], size = 10): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

function buildDisplayName(p: any): string {
  const dn = p?.displayName;
  const first = p?.firstName;
  const last = p?.lastName;
  if (dn && typeof dn === 'string') return dn;
  const combined = `${first ?? ''} ${last ?? ''}`.trim();
  return combined || 'Passenger';
}

export async function GET(
  _req: Request,
  { params }: { params: { rideId: string } }
) {
  try {
    const db = getDb();

    // bookings under rides/{rideId}/bookings/*
    const bookingsSnap = await db
      .collection('rides')
      .doc(params.rideId)
      .collection('bookings')
      .get();

    const bookings = bookingsSnap.docs.map(d => ({ id: d.id, ...(d.data() as any) }));

    // Support both userUid and userId
    const userIds = [
      ...new Set(
        bookings
          .map(b => b.userUid ?? b.userId)
          .filter((v: unknown): v is string => typeof v === 'string' && v.length > 0)
      ),
    ];

    // Empty state → ok:true with empty list (won't trip your UI)
    if (userIds.length === 0) {
      return NextResponse.json({ ok: true, passengers: [] });
    }

    // Fetch users in chunks of <= 10 for Firestore 'in' constraint
    const chunks = chunk(userIds, 10);
    const userDocs = await Promise.all(
      chunks.map(ids =>
        db.collection('users').where('__name__', 'in', ids).get()
      )
    );

    const usersMap = new Map<string, UserProfile & Record<string, any>>();
    userDocs.forEach(s =>
      s.docs.forEach(doc => usersMap.set(doc.id, doc.data() as any))
    );

    const passengers = bookings.map(b => {
      const uid = b.userUid ?? b.userId;
      const profile = uid ? usersMap.get(uid) : undefined;
      return {
        bookingId: b.id,
        uid,
        seats: b.seats ?? 1,
        status: b.status ?? 'pending',
        user: {
          displayName: buildDisplayName(profile),
          photoURL: profile?.photoURL_public ?? profile?.avatarUrl ?? profile?.photoURL ?? null,
        },
      };
    });

    return NextResponse.json({ ok: true, passengers });
  } catch (e: any) {
    console.error(`Error fetching passengers for ride ${params.rideId}:`, e);
    // Soft error (HTTP 200) so the page never shows a hard failure
    return NextResponse.json({
      ok: false,
      code: 'internal_error',
      message: e?.message ?? 'error fetching passengers',
      passengers: [],
    });
  }
}
